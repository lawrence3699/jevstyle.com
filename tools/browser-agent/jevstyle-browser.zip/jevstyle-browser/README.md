# JevStyle Browser Agent

A JevStyle-powered adaptation of [Browser Use Jev Ultrafast](https://github.com/browser-use/jev-ultrafast).
JevStyle selects an operation and an observed element in one decision request.
A separate text model generates field values only for `TYPE_TEXT`.

## Run locally

Python 3.12+, Chrome, and [uv](https://docs.astral.sh/uv/) are required.

```sh
uv sync
cp .env.example .env
```

Start your JevStyle server separately (`jev-style serve --release 2b`) and configure `.env`:

```dotenv
JEVSTYLE_BASE_URL=http://127.0.0.1:8765
JEVSTYLE_MODEL=jev-style-2b-decision-v4
JEVSTYLE_API_KEY=
TEXT_MODEL_BASE_URL=http://127.0.0.1:1234/v1
TEXT_MODEL_API_KEY=local
TEXT_MODEL=YOUR_LOADED_GENERATIVE_MODEL_ID
TEXT_MODEL_REASONING=none
```

For hosted decisions set `JEVSTYLE_BASE_URL=https://api.jevstyle.com` and your own `JEVSTYLE_API_KEY`.
A JevStyle decision model cannot serve as the text generator: select a normal generative model in LM Studio.
Use the exact identifier returned by its `/v1/models` endpoint. Keys stay in the ignored `.env` file.

```sh
uv run jev
```

Open http://127.0.0.1:8766. Browser Harness connects to Chrome; follow its connection instructions.
For a dedicated test browser, launch Chrome with a separate `--user-data-dir` and
`--remote-debugging-port=19222`, then set `BU_CDP_URL=http://127.0.0.1:19222`.
Do not expose the local inspector or a debugging port publicly.

## Reproduce scenarios

```sh
uv run python scripts/run_scenarios.py --help
uv run --env-file .env python scripts/run_scenarios.py --output artifacts/scenarios
```

The suite checks actual outcomes independently of the model's `DONE` decision. It covers upstream
hotel search and reading, Wikipedia and Google Flights, plus additional form/filter/scroll examples.
Fixture tasks are controlled tests; external websites can change or block automation.
The suite's explicit list is the supported scope, not a claim to operate every website.

## Input budget

`JEVSTYLE_MAX_REQUEST_BYTES=32000` is a wire-byte guard, not a token counter.
The adapter removes old history and shortens page text to fit, preserving goals and all offered targets.
It stops when controls alone cannot fit, or a head exceeds 255 options. Increase the byte setting only
alongside a verified increase of the serving model's token/byte limits. The server is authoritative.

## Evidence and attribution

The public replay on [jevstyle.com](https://jevstyle.com/tools/browser-agent/) uses actual suite output.
It displays the model, verification status and measured elapsed time. A replay is not a live cloud browser.
The local inspector is interactive and executes real actions in Chrome.

The upstream 7.1-second Google Flights recording is an upstream TypeSafe result, not a JevStyle benchmark.
Original methodology is retained in `docs/upstream-readme.md` and `docs/performance.md` for attribution.
JevStyle-specific performance claims must come from the new suite output.

This adaptation retains observed-node mapping, freshness and occlusion checks, and one-use mutation
execution. It does not let models generate executable JavaScript, selectors or shell commands.
Frames, canvas, uploads, popup tabs and arbitrary keyboard widgets remain outside the upstream executor.

## Checks

```sh
uv run ruff check .
uv run pytest
node --check jev_ultrafast/static/app.js
node --check jev_ultrafast/snapshot.js
uv build
```

Tests are offline. Live scenarios call your configured models. See `LICENSE` and `NOTICE` for attribution.
