"""Progress must survive DOM re-rendering without weakening execution guards."""

import time
from copy import deepcopy
from unittest.mock import Mock

import pytest

from jev_ultrafast import agent, model
from jev_ultrafast.progress import CYCLE_WINDOW, action_signature, no_progress, repeated_noops, semantic_key


def page():
    return {
        "url": "https://example.test/catalog", "title": "Catalog", "text": "Search catalog Open item",
        "scroll": {"x": 0, "y": 0}, "fingerprint": "original", "goal_feedback": {"passed": False},
        "actions": [
            {"id": "search", "node": 1, "kind": "click", "label": "Search catalog", "role": "button"},
            {"id": "item", "node": 2, "kind": "click", "label": "Open item", "role": "link"},
            {"id": "query", "node": 3, "kind": "fill", "label": "Query", "role": "textbox", "value": "book"},
            {"id": "wait", "kind": "wait", "label": "Wait"},
        ],
    }


def noop(p, action):
    key = semantic_key(p)
    return {"action": action["label"], "kind": action["kind"], "action_signature": action_signature(action),
            "semantic_before": key, "semantic_after": key, "semantic_changed": False, "page_changed": True}


def test_rerendered_nodes_geometry_and_feedback_are_not_progress():
    before = page()
    after = deepcopy(before)
    after.update(fingerprint="rerendered", marker="new", screenshot="different", w=900, h=700,
                 goal_feedback={"passed": True})
    for i, action in enumerate(after["actions"]):
        action.update(id=f"new-{i}", node=i + 100, x=40, y=60, rect={"width": 123})
    after["actions"].reverse()
    assert semantic_key(before) == semantic_key(after)


@pytest.mark.parametrize("change", ["value", "current_value", "checked", "selected", "expanded", "scroll", "url",
                                   "text", "role", "label", "kind"])
def test_meaningful_state_changes_are_progress(change):
    before = page()
    after = deepcopy(before)
    if change == "scroll":
        after["scroll"]["y"] = 500
    elif change in {"url", "text"}:
        after[change] += "changed"
    else:
        after["actions"][2][change] = True if change in {"checked", "selected", "expanded"} else "changed"
    assert semantic_key(before) != semantic_key(after)


def test_signature_ignores_node_identity_but_distinguishes_operations_and_values():
    original = page()["actions"][2]
    assert action_signature(original) == action_signature({**original, "node": 99, "id": "new"})
    assert action_signature(original) != action_signature({**original, "kind": "click"})
    assert action_signature(original) != action_signature({**original, "value": "another query"})


def test_mask_requires_two_noops_and_resets_on_real_progress():
    p = page()
    item = noop(p, p["actions"][0])
    assert repeated_noops(p, [item]) == set()
    assert repeated_noops(p, [item, item]) == {item["action_signature"]}
    changed = {**item, "semantic_before": "earlier", "semantic_changed": True}
    assert repeated_noops(p, [item, item, changed]) == set()
    assert repeated_noops(p, [item, item, {**item, "semantic_after": None}]) == set()


def test_wait_never_masked_and_legacy_trace_does_not_create_mask():
    p = page()
    wait = noop(p, p["actions"][-1])
    assert repeated_noops(p, [wait] * 5) == set()
    assert repeated_noops(p, [{"action": "Search catalog", "page_changed": False}] * 5) == set()
    assert no_progress({"page_changed": False})
    assert no_progress({"page_changed": True, "semantic_changed": False})
    assert not no_progress({"page_changed": False, "semantic_changed": True})


def test_repeated_state_action_transition_is_masked_without_blocking_other_targets():
    p = page()
    transition = {**noop(p, p["actions"][0]), "semantic_after": "another-state", "semantic_changed": True}
    return_step = {**noop(p, p["actions"][1]), "semantic_before": "another-state", "semantic_changed": True}
    assert repeated_noops(p, [transition, return_step]) == set()
    history = [transition, return_step] * 2
    assert repeated_noops(p, history) == {transition["action_signature"]}
    # Same before/action but a distinct observed result is exploration, not the same cycle.
    assert repeated_noops(p, [transition, {**transition, "semantic_after": "new-result"}]) == set()
    assert repeated_noops(p, [{**transition, "semantic_after": None}] * 2) == set()
    assert repeated_noops(p, [{**transition, "kind": "wait"}] * 2) == set()
    assert repeated_noops(p, history + [noop(p, p["actions"][-1])] * CYCLE_WINDOW) == set()


def _choice(criteria, selected):
    return {"choice": selected, "confidence": 1.0,
            "probabilities": {key: float(key == selected) for key in criteria}}


def test_mask_preserves_other_indices_and_live_action_mapping(monkeypatch):
    p = page()
    history = [noop(p, p["actions"][0])] * 2
    for i, action in enumerate(p["actions"]):
        if action["kind"] != "wait":
            action.update(id=f"new-{i}", node=i + 100)
    seen = []
    def post(_url, _key, body):
        seen.append(body)
        return {"model": "test", "answers": {
            "operation": _choice(body["questions"]["operation"]["criteria"], "CLICK"),
            "click_target": _choice(body["questions"]["click_target"]["criteria"], "2"),
        }}
    monkeypatch.setattr(model, "post_json", post)
    monkeypatch.setenv("JEVSTYLE_FALLBACK", "0")
    result = model.choose(p, "Open the item", history)
    assert result["target"] == "2" and result["choice"] == "new-1"
    assert set(seen[0]["questions"]["click_target"]["criteria"]) == {"2"}
    assert set(seen[0]["questions"]["type_text_target"]["criteria"]) == {"3"}
    assert seen[0]["state"]["recent_actions"][0]["semantic_changed"] is False


def test_empty_operation_head_removed_but_wait_remains(monkeypatch):
    p = page()
    history = [noop(p, action) for action in p["actions"] for _ in range(2)]
    def post(_url, _key, body):
        assert set(body["questions"]) == {"operation"}
        assert set(body["questions"]["operation"]["criteria"]) == {"WAIT", "BLOCKED"}
        return {"model": "test", "answers": {
            "operation": _choice(body["questions"]["operation"]["criteria"], "WAIT")}}
    monkeypatch.setattr(model, "post_json", post)
    monkeypatch.setenv("JEVSTYLE_FALLBACK", "0")
    assert model.choose(p, "Open the item", history)["choice"] == "wait"


def test_execution_records_semantic_noop_even_with_new_dom_fingerprint():
    p = page()
    after = deepcopy(p)
    after["fingerprint"] = "new-dom"
    for action in after["actions"]:
        if "node" in action:
            action["node"] += 100
    runner = agent.Agent.__new__(agent.Agent)
    runner.screenshots = False
    runner.pending_text = None
    runner.state = {
        "browser": Mock(observe=Mock(return_value=after)), "page": p, "goal": "Open item", "history": [],
        "decision": {"choice": "search", "probabilities": {"search": 1.0}, "confidence": 1.0,
                     "latency_ms": 10, "operation": "CLICK", "target": "1", "usage": {}},
        "status": "predicted", "started_at": time.perf_counter(), "record": False,
    }
    runner.command("act", {"fingerprint": p["fingerprint"]})
    observed = runner.state["history"][0]
    assert observed["page_changed"] is True and observed["semantic_changed"] is False
    assert observed["semantic_before"] == observed["semantic_after"] == semantic_key(p)
    assert observed["action_signature"] == action_signature(p["actions"][0])
    runner.state["browser"].act.assert_called_once()


@pytest.mark.parametrize("choices,status", [(["search", "search", "search"], "blocked"),
                                           (["search", "item", "search"], "ready")])
def test_noop_stop_keeps_distinct_action_exploration_available(choices, status):
    p = page()
    runner = agent.Agent.__new__(agent.Agent)
    runner.screenshots = False
    runner.pending_text = None
    runner.state = {
        "browser": Mock(observe=Mock(return_value=p)), "page": p, "goal": "Open item", "history": [],
        "status": "predicted", "started_at": time.perf_counter(), "record": False,
    }
    for selected in choices:
        runner.state["decision"] = {
            "choice": selected, "probabilities": {selected: 1.0}, "confidence": 1.0, "latency_ms": 10,
            "operation": "CLICK", "target": "1" if selected == "search" else "2", "usage": {},
        }
        runner.command("act", {"fingerprint": runner.state["page"]["fingerprint"]})
    assert runner.state["status"] == status
