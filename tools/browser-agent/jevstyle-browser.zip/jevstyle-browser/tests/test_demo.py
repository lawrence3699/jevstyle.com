"""Preset result checks stop execution without accepting custom-goal shortcuts."""
from unittest.mock import Mock

import pytest

from jev_ultrafast import demo
from jev_ultrafast.scenarios import scenario_catalog


def fake_agent(goal):
    agent = Mock()
    agent.state = {'status': 'ready', 'scenario': 'reading', 'goal': goal, 'verification': {}, 'page': {}}
    agent.snapshot.side_effect = lambda: agent.state.copy()
    return agent


def test_preset_stops_on_independent_result(monkeypatch):
    preset = next(s for s in scenario_catalog() if s['id'] == 'reading')
    agent = fake_agent(preset['goal'])
    monkeypatch.setattr(demo, 'AGENT', agent)
    monkeypatch.setattr(demo, 'verify_outcome', Mock(return_value={'passed': True, 'checks': []}))
    result = demo.command('tick', {})
    assert result['status'] == 'done'
    assert result['completion_source'] == 'independent_verifier'
    assert agent.state['decision'] is None
    agent.command.assert_called_once_with('tick', {})


def test_custom_goal_never_uses_preset_success(monkeypatch):
    agent = fake_agent('Read all articles, not just this one')
    monkeypatch.setattr(demo, 'AGENT', agent)
    verifier = Mock()
    monkeypatch.setattr(demo, 'verify_outcome', verifier)
    assert demo.command('tick', {})['status'] == 'ready'
    verifier.assert_not_called()


def test_failed_result_does_not_stop_active_preset(monkeypatch):
    preset = next(s for s in scenario_catalog() if s['id'] == 'reading')
    agent = fake_agent(preset['goal'])
    monkeypatch.setattr(demo, 'AGENT', agent)
    monkeypatch.setattr(demo, 'verify_outcome', Mock(return_value={'passed': False, 'checks': []}))
    assert demo.command('tick', {})['status'] == 'ready'


def test_unknown_scenario_never_closes_browser(monkeypatch):
    close = Mock()
    monkeypatch.setattr(demo, 'close_browser', close)
    with pytest.raises(ValueError, match='Unknown demo scenario'):
        demo.command('reset', {'scenario': 'arbitrary', 'goal': 'test'})
    close.assert_not_called()


def test_premature_done_is_rejected_for_preset(monkeypatch):
    preset = next(s for s in scenario_catalog() if s['id'] == 'reading')
    agent = fake_agent(preset['goal'])
    agent.state['page'] = {}
    agent.state['status'] = 'done'
    monkeypatch.setattr(demo, 'AGENT', agent)
    monkeypatch.setattr(demo, 'verify_outcome', Mock(return_value={'passed': False, 'checks': []}))
    result = demo.command('tick', {})
    assert result['status'] == 'ready'
    assert result['page']['goal_feedback']['passed'] is False
