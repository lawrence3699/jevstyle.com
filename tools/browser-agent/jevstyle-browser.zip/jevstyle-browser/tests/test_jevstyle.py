"""Offline provider boundaries; these tests never contact model services."""
from copy import deepcopy
from unittest.mock import Mock

import httpx
import pytest

from jev_ultrafast import model


@pytest.mark.parametrize('base,expected', [
    ('http://127.0.0.1:8765', 'http://127.0.0.1:8765/v1/systemone'),
    ('http://localhost:8765/v1', 'http://localhost:8765/v1/systemone'),
    ('https://api.jevstyle.com/v1/systemone', 'https://api.jevstyle.com/v1/systemone'),
])
def test_endpoint_normalization(monkeypatch, base, expected):
    monkeypatch.setenv('JEVSTYLE_BASE_URL', base)
    monkeypatch.setenv('JEVSTYLE_API_KEY', 'test')
    assert model.decision_endpoint() == (expected, 'test')


def test_typesafe_secret_never_used_for_jevstyle(monkeypatch):
    monkeypatch.setenv('JEVSTYLE_BASE_URL', 'https://api.jevstyle.com')
    monkeypatch.delenv('JEVSTYLE_API_KEY', raising=False)
    monkeypatch.setenv('TYPESAFE_API_KEY', 'different-service-secret')
    with pytest.raises(ValueError, match='JEVSTYLE_API_KEY'):
        model.decision_endpoint()


@pytest.mark.parametrize('url', ['http://example.test', 'https://user:pass@example.test',
                                 'https://example.test?key=x', 'file:///tmp/model'])
def test_unsafe_endpoint_rejected(monkeypatch, url):
    monkeypatch.setenv('JEVSTYLE_BASE_URL', url)
    with pytest.raises(ValueError):
        model.decision_endpoint()


def test_byte_budget_preserves_goal_and_all_targets(monkeypatch):
    monkeypatch.setenv('JEVSTYLE_MAX_REQUEST_BYTES', '1024')
    body = {'state': {'page': {'text': '网页' * 2000}, 'recent_actions': ['long' * 1000]},
            'questions': {'operation': {'instructions': 'Find something', 'criteria': {'CLICK': 'click'}},
                          'click_target': {'criteria': {'7': {'element': 'Search'}}}}}
    questions = deepcopy(body['questions'])
    model.fit_request(body)
    assert body['questions'] == questions
    assert not body['state']['recent_actions']
    assert len(body['state']['page']['text']) < 4000


def test_controls_cannot_be_silently_dropped(monkeypatch):
    monkeypatch.setenv('JEVSTYLE_MAX_REQUEST_BYTES', '1024')
    body = {'state': {'page': {'text': ''}, 'recent_actions': []},
            'questions': {'target': {'criteria': {'1': 'x' * 2000}}}}
    with pytest.raises(ValueError, match='input budget'):
        model.fit_request(body)


def test_non_json_reply_fails_closed(monkeypatch):
    reply = httpx.Response(200, text='<html>login</html>')
    monkeypatch.setattr(model.CLIENT, 'post', Mock(return_value=reply))
    with pytest.raises(ValueError, match='invalid JSON'):
        model.post_json('http://127.0.0.1', '', {})


def test_local_requests_have_no_fake_bearer(monkeypatch):
    post = Mock(return_value=httpx.Response(200, json={}))
    monkeypatch.setattr(model.CLIENT, 'post', post)
    model.post_json('http://127.0.0.1', '', {})
    assert post.call_args.kwargs['headers'] == {}


def test_large_target_descriptions_keep_all_candidates_and_state(monkeypatch):
    monkeypatch.setenv('JEVSTYLE_MAX_REQUEST_BYTES', '50000')
    rows = [[str(i), 'checkbox', f'Option {i}', '', ['CLICK'], {'checked': i == 7}]
            for i in range(100)]
    criteria = {str(i): {'element': f'[{i}] Option {i}', 'role': 'checkbox',
                         'current_value': 'x' * 150, 'checked': i == 7} for i in range(100)}
    body = {'state': {'elements': rows, 'page': {'text': ''}, 'recent_actions': []},
            'questions': {'click_target': {'criteria': criteria}}}
    original_rows = deepcopy(rows)
    fitted = model.fit_request(body)
    assert set(fitted['questions']['click_target']['criteria']) == set(criteria)
    assert fitted['questions']['click_target']['criteria']['7'] == '[7] Option 7'
    assert fitted['state']['elements'] == original_rows
