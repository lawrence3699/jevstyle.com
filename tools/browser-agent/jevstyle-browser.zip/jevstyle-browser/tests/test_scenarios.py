"""Offline verifier and public-evidence regressions; never call models or browsers."""

import base64
import json
from copy import deepcopy
from datetime import date

import pytest

from jev_ultrafast.scenarios import public_steps, scenario_catalog, verification_feedback, verify_outcome
from scripts.run_scenarios import evaluate_run, progress_event


def scenario(name):
    return next(s for s in scenario_catalog("2027-02-10") if s["id"] == name)


def test_catalog_future_date_and_unique_tasks():
    catalog = scenario_catalog()
    assert len({s["id"] for s in catalog}) == 8
    assert sum(s["local"] for s in catalog) == 6
    assert date.fromisoformat(catalog[-1]["departure"]) > date.today()
    assert "February 10, 2027" in scenario("flights")["goal"]


@pytest.mark.parametrize("task", [s["id"] for s in scenario_catalog()])
def test_empty_page_never_passes(task):
    assert verify_outcome(scenario(task), {})["passed"] is False


def test_hotel_must_apply_filters_not_just_open_property():
    evidence = {"url": "http://localhost/fixture.html#casa-flora", "heading": "Casa Flora",
                "text": "Your filters: all · Free cancellation off · Destination anywhere"}
    assert not verify_outcome(scenario("hotel"), evidence)["passed"]
    evidence["text"] = "Your filters: Design · Free cancellation enabled · Destination Lisbon"
    assert verify_outcome(scenario("hotel"), evidence)["passed"]
    evidence["text"] = "Your filters: Design · Free cancellation enabled · Destination LISBON"
    assert verify_outcome(scenario("hotel"), evidence)["passed"]


def test_form_checks_submitted_receipt_values():
    evidence = {"url": "http://localhost/#request-sent", "heading": "Request received", "receipt": {
        "name": "Alex Chen", "email": "alex.chen@example.com", "topic": "Billing",
        "message": "I was charged twice.", "copy": "Yes",
    }}
    assert verify_outcome(scenario("form"), evidence)["passed"]
    for field in evidence["receipt"]:
        bad = deepcopy(evidence)
        bad["receipt"][field] = "wrong"
        assert not verify_outcome(scenario("form"), bad)["passed"]


def test_catalog_requires_applied_query_not_merely_typed_text():
    evidence = {"url": "http://localhost/#studio-lite", "product": "Studio Lite headphones", "query": "headphones",
                "category": "audio", "stock": True, "sort": "price-asc", "applied": {
                    "query": "", "category": "audio", "stock": "true", "sort": "price-asc"}}
    assert not verify_outcome(scenario("catalog"), evidence)["passed"]
    evidence["applied"]["query"] = "headphones"
    assert verify_outcome(scenario("catalog"), evidence)["passed"]


def test_feedback_acknowledges_filled_controls_but_still_requires_submission():
    evidence = {"url": "http://localhost/", "form_values": {
        "name": "Alex Chen", "email": "alex.chen@example.com", "topic": "Billing",
        "message": "I was charged twice", "copy": "Yes"}}
    verification = verify_outcome(scenario("form"), evidence)
    assert not verification["passed"]
    assert {c["name"] for c in verification["checks"] if not c["passed"]} == {"submission receipt"}
    evidence = {"url": "http://localhost/", "category": "Design", "cancellation": True,
                "hotel_search": "1 places in LISBON"}
    verification = verify_outcome(scenario("hotel"), evidence)
    assert {c["name"] for c in verification["checks"] if not c["passed"]} == {
        "correct property opened", "property heading"}


def test_wikipedia_requires_exact_domain_and_heading():
    evidence = {"url": "https://en.wikipedia.org/wiki/G%C3%B6del%27s_incompleteness_theorems",
                "heading": "Gödel's incompleteness theorems"}
    assert verify_outcome(scenario("wikipedia"), evidence)["passed"]
    evidence["url"] = evidence["url"].replace("en.wikipedia.org", "en.wikipedia.org.evil.test")
    assert not verify_outcome(scenario("wikipedia"), evidence)["passed"]


def test_public_export_discards_untrusted_text_and_nonfinite_scores():
    secret = "sk-secret-email@example.com"
    state = {
        "history": [{"operation": "TYPE_TEXT", "target": "12", "action": secret, "text": secret,
                     "url": "https://example.test/?key=" + secret, "confidence": float("nan"),
                     "latency_ms": 5, "elapsed_ms": 10,
                     "operation_probabilities": {"TYPE_TEXT": .9, secret: .1},
                     "target_probabilities": {"12": 1., secret: 0.},
                     "decision_source": "local_fallback", "fallback_model": "test-local"}],
        "decisions": [{"operation": "TYPE_TEXT", "request": {"key": secret},
                       "operation_probabilities": {"TYPE_TEXT": .9, secret: .1},
                       "target_probabilities": {"12": .8, secret: .2}}],
    }
    steps, decisions = public_steps(state)
    encoded = json.dumps([steps, decisions], allow_nan=False)
    assert secret not in encoded
    assert steps[0]["label"] == "TYPE_TEXT element 12"
    assert steps[0]["confidence"] is None
    assert steps[0]["operation_probabilities"] == {"TYPE_TEXT": .9}
    assert steps[0]["target_probabilities"] == {"12": 1.}
    assert steps[0]["decision_source"] == "local_fallback"
    assert steps[0]["probability_source"] == "jevstyle"
    assert steps[0]["fallback_model"] == "test-local"
    assert decisions[0]["target_probabilities"] == {"12": .8}


def test_verified_stop_is_distinct_from_model_done_and_budget_failure(tmp_path):
    class FakeBrowser:
        def observe(self, **_kwargs):
            return {}

        def evaluate(self, _expression):
            return {"url": "http://localhost/fixture.html#uncertainty", "heading": "Confidence is not correctness",
                    "text": "Measure the complete loop against an observable result."}

    class FakeAgent:
        def __init__(self, *_args):
            self.browser = FakeBrowser()
            self.state = {"status": "ready", "page": {}, "elapsed_ms": 10,
                          "history": [{"operation": "CLICK", "target": "1"}],
                          "decisions": [{"operation": "CLICK", "model": "test"}], "text_calls": []}

        def run(self):
            yield self.state
            raise AssertionError("The verifier should have stopped this completed task")

        def snapshot(self):
            return self.state

        def close(self):
            pass

    events = []
    run = evaluate_run(scenario("reading"), "http://localhost", tmp_path, agent_factory=FakeAgent,
                       progress_callback=events.append)
    assert run["status"] == "passed"
    assert run["agent_status"] == "ready"
    assert run["completion_source"] == "independent_verifier"
    assert run["verification"]["passed"] is True
    assert events == [{"step": 1, "operation": "CLICK", "elapsed_ms": 10, "checks_passed": 3, "checks_total": 3}]
    assert (tmp_path / "reading-live-private.json").exists()
    # A task that reaches the right page but exhausts its budget without stopping is
    # not relabelled as successful in the original model-stop-only measurement mode.
    run = evaluate_run(scenario("reading"), "http://localhost", tmp_path, agent_factory=FakeAgent,
                       max_actions=1, stop_when_verified=False)
    assert run["status"] == "failed"
    assert run["verification"]["passed"] is True
    assert run["error"]["type"] == "TimeoutError"


def test_progress_does_not_include_untrusted_page_or_action_text():
    event = progress_event({"history": [{"operation": "private-secret", "action": "private-secret"}],
                            "page": {"text": "private-secret"}, "elapsed_ms": float("nan")},
                           {"checks": [{"name": "private-secret", "passed": False}]})
    assert event == {"step": 1, "operation": "UNKNOWN", "elapsed_ms": None,
                     "checks_passed": 0, "checks_total": 1}
    assert "private-secret" not in json.dumps(event, allow_nan=False)


def test_modal_hidden_flight_controls_are_unknown_only_in_intermediate_feedback():
    s = scenario("flights")
    evidence = {"url": s["url"], "text": "Choose departure date"}
    page = {"actions": [{"label": "Departure", "value": "", "role": "textbox"}]}
    feedback = verification_feedback(s, evidence, page)
    checks = {c["name"]: c["passed"] for c in feedback["checks"]}
    assert checks["one way"] is None and checks["one passenger"] is None
    assert checks["economy cabin"] is None and checks["Zürich origin committed"] is None
    assert checks["departure date"] is False and feedback["passed"] is False
    strict = verify_outcome(s, evidence, page)
    assert all(c["passed"] is False for c in strict["checks"])
    page["actions"] += [
        {"label": "Select your ticket type. One way", "value": "One way"},
        {"label": "1 passenger", "value": ""},
        {"label": "Change seating class. Economy", "value": "Economy"},
    ]
    checks = {c["name"]: c["passed"] for c in verification_feedback(s, evidence, page)["checks"]}
    assert checks["one way"] is True and checks["one passenger"] is True and checks["economy cabin"] is True
    page["actions"][1] = {"label": "Select your ticket type. Round trip", "value": "Round trip"}
    checks = {c["name"]: c["passed"] for c in verification_feedback(s, evidence, page)["checks"]}
    assert checks["one way"] is False


def test_final_frame_is_captured_privately_before_browser_closes(tmp_path):
    events = []
    frame_bytes = b"test-browser-frame"

    class FakeBrowser:
        def observe(self, *, screenshot):
            events.append(("observe", screenshot))
            return {"screenshot": base64.b64encode(frame_bytes).decode()} if screenshot else {}

        def evaluate(self, _expression):
            return {"url": "http://localhost/fixture.html#uncertainty", "heading": "Confidence is not correctness",
                    "text": "Measure the complete loop against an observable result."}

    class FakeRecordedAgent:
        def __init__(self, _url, _goal, *, record_dir, screenshots):
            assert screenshots is True
            record_dir.mkdir()
            (record_dir / "000000.jpg").write_bytes(frame_bytes)
            self.browser = FakeBrowser()
            self.state = {"status": "ready", "page": {}, "elapsed_ms": 10,
                          "history": [{"operation": "CLICK", "target": "1"}],
                          "decisions": [{"operation": "CLICK", "model": "test"}], "text_calls": []}

        def run(self):
            yield self.state

        def snapshot(self):
            return self.state

        def close(self):
            events.append(("close", None))

    run = evaluate_run(scenario("reading"), "http://localhost", tmp_path,
                       agent_factory=FakeRecordedAgent, record_frames=True)
    assert run["status"] == "passed"
    assert run["capture_enabled"] is True and run["final_frame_captured"] is True
    assert run["captured_frames"] == 2
    assert (tmp_path / "reading-frames" / "final.jpg").read_bytes() == frame_bytes
    assert events[-2:] == [("observe", True), ("close", None)]
    assert "screenshot" not in json.dumps(run)
