"""Explicit live browser/model evaluation; not a pytest test or a simulated benchmark.

Examples:
  uv run python scripts/run_scenarios.py --list
  uv run --env-file .env python scripts/run_scenarios.py --local-only --output artifacts/scenarios/local
  uv run --env-file .env python scripts/run_scenarios.py --scenario flights --flight-date 2027-02-10
"""

import argparse
import functools
import json
import threading
import time
from contextlib import contextmanager
from datetime import datetime, timezone
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

from jev_ultrafast.scenarios import EVIDENCE_JS, public_steps, scenario_catalog, verify_outcome

STATIC = Path(__file__).resolve().parents[1] / "jev_ultrafast" / "static"


class QuietHandler(SimpleHTTPRequestHandler):
    def log_message(self, *_args):
        pass


@contextmanager
def fixture_server():
    handler = functools.partial(QuietHandler, directory=str(STATIC))
    server = ThreadingHTTPServer(("127.0.0.1", 0), handler)
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    try:
        yield f"http://127.0.0.1:{server.server_port}"
    finally:
        server.shutdown()
        server.server_close()
        thread.join(timeout=2)


def evaluate_run(scenario, base_url, output, *, max_actions=40, max_seconds=180, agent_factory=None,
                 stop_when_verified=True):
    if agent_factory is None:
        from jev_ultrafast import Agent
        agent_factory = Agent
    state, evidence, verification, error = {}, {}, {"passed": False, "checks": []}, None
    started = time.perf_counter()
    agent = None
    completion_source = None
    verification_checks = 0
    try:
        url = f"{base_url}/{scenario['path']}" if scenario["local"] else scenario["url"]
        agent = agent_factory(url, scenario["goal"])
        for state in agent.run():
            if stop_when_verified:
                # Acceptance criteria may stop a finished task, but never select or execute actions.
                page = agent.browser.observe(screenshot=False)
                evidence = agent.browser.evaluate(EVIDENCE_JS)
                verification = verify_outcome(scenario, evidence, page)
                verification_checks += 1
                if verification["passed"]:
                    completion_source = "independent_verifier"
                    break
            if state["status"] not in {"done", "blocked"} and len(state["history"]) >= max_actions:
                raise TimeoutError("Action budget exhausted")
            if time.perf_counter() - started > max_seconds:
                raise TimeoutError("Wall-clock budget exhausted")
    except Exception as exc:
        # Public errors are an allowlist. Provider/network errors can contain private input.
        error = {"type": type(exc).__name__, "message": "Run did not complete; see the private diagnostic file."}
        (output / f"{scenario['id']}-diagnostic.txt").write_text(f"{type(exc).__name__}: {exc}\n")
    finally:
        if agent is not None:
            state = agent.snapshot()
            # Verify failed/budget-exhausted attempts too. This distinguishes a failure
            # to stop from a failure to achieve the actual application outcome.
            try:
                page = agent.browser.observe(screenshot=False)
                evidence = agent.browser.evaluate(EVIDENCE_JS)
                verification = verify_outcome(scenario, evidence, page)
                verification_checks += 1
            except Exception:
                if error is None:
                    error = {"type": "VerificationError", "message": "Fresh outcome verification failed."}
            try:
                agent.close()
            except Exception:
                if error is None:
                    error = {"type": "CleanupError", "message": "The browser tab could not be closed."}
        # Keep debugging data outside the single public runs.json file.
        (output / f"{scenario['id']}-private.json").write_text(json.dumps({
            "state": state, "evidence": evidence,
        }, ensure_ascii=False, indent=2))
    steps, decisions = public_steps(state)
    status = "passed" if verification["passed"] and error is None else (
        "blocked" if state.get("status") == "blocked" or not state else "failed"
    )
    if completion_source is None and state.get("status") == "done":
        completion_source = "model_done_then_verified"
    # Completion and agent-reported stopping are distinct so false DONEs remain visible.
    model_names = list(dict.fromkeys(d.get("model", "unknown") for d in state.get("decisions", [])))
    return {
        "id": scenario["id"], "title": scenario["title"], "goal": scenario["goal"],
        "url": scenario.get("path", scenario.get("url")), "local": scenario["local"],
        "status": status, "agent_status": state.get("status", "not_started"),
        "completion_source": completion_source, "verification_checks": verification_checks,
        "elapsed_ms": state.get("elapsed_ms", 0), "wall_ms": round((time.perf_counter() - started) * 1000),
        "model": ", ".join(model_names) or "not_called", "verification": verification,
        "error": error, "steps": steps, "decisions": decisions,
        "decision_calls": len(state.get("decisions", [])), "text_calls": len(state.get("text_calls", [])),
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--list", action="store_true", help="Print scenario definitions without browser/model calls")
    parser.add_argument("--scenario", action="append", help="Scenario ID; repeat for multiple scenarios")
    parser.add_argument("--local-only", action="store_true", help="Only local synthetic fixtures")
    parser.add_argument("--flight-date", help="Future departure date in YYYY-MM-DD; default today + 90 days")
    parser.add_argument("--output", help="Result directory; publish only runs.json")
    parser.add_argument("--max-actions", type=int, default=40)
    parser.add_argument("--max-seconds", type=float, default=180)
    parser.add_argument("--model-stop-only", action="store_true",
                        help="Wait for model DONE instead of verifier stopping")
    args = parser.parse_args()
    catalog = scenario_catalog(args.flight_date)
    if args.list:
        print(json.dumps(catalog, ensure_ascii=False, indent=2))
        return
    if args.max_actions < 1 or args.max_seconds <= 0:
        parser.error("Budgets must be positive")
    unknown = set(args.scenario or []) - {item["id"] for item in catalog}
    if unknown:
        parser.error("Unknown scenario: " + ", ".join(sorted(unknown)))
    selected = [s for s in catalog if (not args.scenario or s["id"] in args.scenario)
                and (not args.local_only or s["local"])]
    if not selected:
        parser.error("No scenarios selected")
    from jev_ultrafast.demo import load_environment
    load_environment()
    timestamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%fZ")
    output = Path(args.output or f"artifacts/scenarios/{timestamp}")
    output.mkdir(parents=True, exist_ok=True)
    report = {
        "schema_version": 1, "generated_at": datetime.now(timezone.utc).isoformat(),
        "model": "see individual runs", "runs": [],
        "measurement": {
            "elapsed_ms": "Agent decision loop; excludes browser setup and independent final verification",
            "wall_ms": "Browser setup, decision loop, independent verification and cleanup",
            "scope": "Live attempts on named tasks; synthetic fixtures are not a general web benchmark",
            "replay": "Executed actions and separate decision scores; no recorded video or simulated actions",
        },
    }
    with fixture_server() as base_url:
        for scenario in selected:
            print(f"Running {scenario['id']}…", flush=True)
            run = evaluate_run(scenario, base_url, output, max_actions=args.max_actions, max_seconds=args.max_seconds,
                               stop_when_verified=not args.model_stop_only)
            report["runs"].append(run)
            report["summary"] = {key: sum(r["status"] == key for r in report["runs"])
                                 for key in ("passed", "failed", "blocked")}
            (output / "runs.json").write_text(json.dumps(report, ensure_ascii=False, indent=2, allow_nan=False))
            print(f"{scenario['id']}: {run['status']} · {run['elapsed_ms']} ms · "
                  f"{run['decision_calls']} decisions · {run['text_calls']} text calls", flush=True)
    print(f"Public replay: {output / 'runs.json'}", flush=True)
    if any(r["status"] != "passed" for r in report["runs"]):
        raise SystemExit(1)


if __name__ == "__main__":
    main()
