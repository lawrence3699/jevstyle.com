"""Local-browser freshness/execution regressions. No model calls or external websites."""

from urllib.parse import quote

from jev_ultrafast.browser import Browser, StalePage

HTML = """<!doctype html><title>Guard checks</title>
<style>body{margin:30px}button{width:180px;height:50px}
#target{display:block;margin-bottom:12px}#outside{position:absolute;top:3000px}</style>
<p id="context">Cart total: $10</p>
<button id="target" onclick="window.clicks=(window.clicks||0)+1">Continue</button>
<label>City<input id="field" value="Zurich"></label>
<label><input id="toggle" type="checkbox">Refundable</label>
<select aria-label="Category"><option>All</option><option>Design</option></select>
<p id="outside">Unrelated offscreen text</p>"""

HIT_TEST_HTML = """<!doctype html><title>Observed center eligibility</title>
<style>
body{margin:0}button{position:absolute;width:180px;height:60px}
#clip{position:absolute;left:40px;top:40px;width:100px;height:80px;overflow:hidden}
#clipped{left:160px;top:10px;width:100px;height:40px}
#normal{left:40px;top:160px}#normal span{position:absolute;inset:0;display:grid;place-items:center}
#covered{left:40px;top:250px}#late{left:40px;top:350px}
#cover{position:absolute;left:40px;top:250px;width:180px;height:60px;z-index:10;background:white}
</style>
<div id="clip"><button id="clipped">Clipped control</button></div>
<button id="normal" onclick="window.normalClicks=(window.normalClicks||0)+1"><span>Visible control</span></button>
<button id="covered">Covered control</button><div id="cover"></div>
<button id="late" onclick="window.lateClicks=(window.lateClicks||0)+1">Late covered control</button>"""


def check_observation_hit_testing(passed):
    browser = Browser("data:text/html," + quote(HIT_TEST_HTML))
    try:
        diagnostic = browser.evaluate("""(() => {
          const e=document.querySelector('#clipped'),r=e.getBoundingClientRect();
          const x=r.x+r.width/2,y=r.y+r.height/2;
          return {css_visible:e.checkVisibility({checkOpacity:true,checkVisibilityCSS:true}),
            center_in_viewport:x>=0&&y>=0&&x<innerWidth&&y<innerHeight,
            center_hits_target:e.contains(document.elementFromPoint(x,y))};
        })()""")
        assert diagnostic == {"css_visible": True, "center_in_viewport": True, "center_hits_target": False}
        page = browser.observe(screenshot=False)
        labels = {a["label"] for a in page["actions"]}
        assert "Clipped control" not in labels
        assert "Covered control" not in labels
        assert {"Visible control", "Late covered control"} <= labels
        passed.append("ancestor-clipped and overlaid centers are not offered as actions")

        normal = next(a for a in page["actions"] if a["label"] == "Visible control")
        browser.act(normal, page)
        assert browser.evaluate("window.normalClicks") == 1
        passed.append("visible control remains executable when its descendant receives the hit")

        page = browser.observe(screenshot=False)
        late = next(a for a in page["actions"] if a["label"] == "Late covered control")
        browser.evaluate("const lateCover=document.createElement('div'); "
                         "lateCover.style.cssText='position:absolute;left:40px;top:350px;"
                         "width:180px;height:60px;z-index:20;background:white';document.body.append(lateCover)")
        assert browser.fresh(page, late), "The late overlay is not a DOM-identity/form-value change"
        try:
            browser.act(late, page)
        except StalePage:
            pass
        else:
            raise AssertionError("A post-observation overlay must still block input")
        assert not browser.evaluate("window.lateClicks")
        passed.append("execution still rejects an overlay that appears after observation")

        browser.evaluate("document.querySelector('#cover').style.pointerEvents='none'; "
                         "document.querySelector('#clip').style.overflow='visible'")
        page = browser.observe(screenshot=False)
        labels = {a["label"] for a in page["actions"]}
        assert {"Clipped control", "Covered control", "Visible control"} <= labels
        passed.append("revealed controls and pointer-events-none overlays retain eligible actions")
    finally:
        browser.close()


def main():
    passed = []
    check_observation_hit_testing(passed)
    browser = Browser("data:text/html," + quote(HTML))
    try:
        page = browser.observe(screenshot=False)
        action = next(a for a in page["actions"] if a["label"] == "Continue")
        browser.evaluate("document.querySelector('#target').style.transform='translateX(200px)'")
        assert browser.fresh(page), "Movement should use fresh geometry, not another model call"
        browser.act(action, page)
        assert browser.evaluate("window.clicks") == 1
        passed.append("moving target clicked at its current location")

        browser.evaluate("document.querySelector('#outside').textContent='Updated outside the viewport'")
        assert browser.fresh(page)
        passed.append("unrelated offscreen text does not invalidate")

        mutations = {
            "visible context": "document.querySelector('#context').textContent='Cart total: $100'",
            "accessible label": "document.querySelector('#target').setAttribute('aria-label','Delete account')",
            "field property": "document.querySelector('#field').value='London'",
            "checkbox property": "document.querySelector('#toggle').checked=true",
            "disabled target": "document.querySelector('#target').disabled=true",
            "read-only field": "document.querySelector('#field').readOnly=true",
            "hidden target": "document.querySelector('#target').style.display='none'",
            "replaced node": "document.querySelector('#target').outerHTML=document.querySelector('#target').outerHTML",
            "dropdown option": "document.querySelector('select').options[1].text='Coastal'",
        }
        for label, expression in mutations.items():
            browser.evaluate("document.querySelector('#target').style.display='block'; "
                             "document.querySelector('#target').disabled=false")
            page = browser.observe(screenshot=False)
            browser.evaluate(expression)
            assert not browser.fresh(page), label
            passed.append(label + " invalidates")

        browser.evaluate("document.querySelector('#target').disabled=false; "
                         "document.querySelector('#target').style.display='block'")
        page = browser.observe(screenshot=False)
        action = next(a for a in page["actions"] if a["label"] == "Delete account")
        # A textless overlay does not alter the model's semantic state, but must block a click.
        browser.evaluate("const cover=document.createElement('div'); "
                         "cover.style.cssText='position:fixed;inset:0;z-index:9999;background:white'; "
                         "document.body.append(cover)")
        assert browser.fresh(page, action)
        try:
            browser.act(action, page)
        except (RuntimeError, StalePage):
            pass
        else:
            raise AssertionError("Covered target was clicked")
        assert browser.evaluate("window.clicks") == 1
        passed.append("overlay blocked before input")

        browser.evaluate("document.body.innerHTML=" + repr("""
          <form><p id="price">Total $10</p>
          <button type="button" id="buy">Buy</button>
          <label>Search <input id="query" role="combobox" aria-controls="suggestions"></label>
          <div role="listbox" id="suggestions"></div>
          <label><input id="check" type="checkbox">Enabled</label>
          <label><input id="radio" type="radio">Choice</label>
          <input id="readonly" aria-label="Read only" readonly>
          <input id="secret" type="password" value="never expose this">
          <button id="off" disabled>Disabled</button>
          <select id="category" aria-label="Category">
            <option>All</option><option>Design</option><option disabled>Unavailable</option>
          </select></form><aside id="unrelated">News</aside>
        """))
        page = browser.observe(screenshot=False)
        buy = next(a for a in page["actions"] if a["label"] == "Buy")
        browser.evaluate("document.querySelector('#unrelated').textContent='New unrelated news'")
        assert browser.fresh(page, buy)
        assert not browser.fresh(page)
        passed.append("click guard accepts unrelated visible updates; terminal guard rejects them")
        for label, expression in {
            "nearby price": "document.querySelector('#price').textContent='Total $100'",
            "form value": "document.querySelector('#query').value='changed'",
            "form toggle": "document.querySelector('#check').checked=true",
            "target replacement": "document.querySelector('#buy').outerHTML=document.querySelector('#buy').outerHTML",
        }.items():
            page = browser.observe(screenshot=False)
            buy = next(a for a in page["actions"] if a["label"] == "Buy")
            browser.evaluate(expression)
            assert not browser.fresh(page, buy), label
            passed.append(label + " invalidates action-specific guard")

        page = browser.observe(screenshot=False)
        actions = page["actions"]
        for role in ("checkbox", "radio"):
            assert {a["kind"] for a in actions if a.get("role") == role} == {"click"}
        assert {a["kind"] for a in actions if a["label"] == "Read only"} == {"click"}
        assert not any(a["label"] == "Disabled" or a.get("value") == "never expose this" for a in actions)
        assert [a["value"] for a in actions if a["kind"] == "select"] == ["Design"]
        passed.append("native controls expose only supported operations and safe values")

        select = next(a for a in actions if a["kind"] == "select")
        browser.act(select, page)
        assert browser.evaluate("document.querySelector('#category').value") == "Design"
        passed.append("native dropdown selects an observed option")

        browser.evaluate("document.querySelector('#query').addEventListener('input',()=>setTimeout(()=>{"
                         "document.querySelector('#suggestions').innerHTML='<div role=option>Generated</div>'"
                         "},60))")
        page = browser.observe(screenshot=False)
        field = next(a for a in page["actions"] if a["kind"] == "fill")
        browser.act(field, page, text="Generated")
        page = browser.observe(screenshot=False)
        value = browser.evaluate("document.querySelector('#query').value")
        assert value == "Generated", repr(value)
        assert any(a.get("role") == "option" for a in page["actions"])
        passed.append("real text input waits for asynchronous combobox suggestions")
        browser.call("Page.navigate", url="about:blank")
        assert not browser.fresh(page, field)
        passed.append("navigation invalidates the old document")
    finally:
        browser.close()
    print("\n".join(passed))
    print(f"PASS: {len(passed)} browser guard checks; no model calls")


if __name__ == "__main__":
    main()
