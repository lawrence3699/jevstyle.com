"""Live JevStyle Google Flights search; never selects or books a flight."""

import argparse
import json
import os
from datetime import date
from pathlib import Path

from jev_ultrafast.scenarios import scenario_catalog, verify_outcome

URL = "https://www.google.com/travel/flights?hl=en"


def flight_scenario(departure=None):
    return next(s for s in scenario_catalog(departure or os.environ.get("JEV_FLIGHT_DATE")) if s["id"] == "flights")


# Imports in the historical measuring/recording scripts now use a future default.
# JEV_FLIGHT_DATE=YYYY-MM-DD sets a reproducible date for those scripts.
GOALS = flight_scenario()["goal"]


def verify(page, departure=None):
    """Independent checks on the resulting page, not the model's DONE answer."""
    result = verify_outcome(flight_scenario(departure), page, page)
    return {
        "passed": result["passed"], "checks": {c["name"]: c["passed"] for c in result["checks"]},
        "visible_flights": [a["label"] for a in page.get("actions", []) if "Select flight" in a["label"]
                            or a["label"].startswith("Flight details. Leaves ")],
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", default="artifacts/flights/latest")
    parser.add_argument("--keep-open", action="store_true")
    parser.add_argument("--flight-date", default=flight_scenario()["departure"], type=date.fromisoformat,
                        help="Future departure date in YYYY-MM-DD; default today + 90 days or JEV_FLIGHT_DATE")
    args = parser.parse_args()
    if args.flight_date <= date.today():
        parser.error("--flight-date must be a future date")
    scenario = flight_scenario(args.flight_date.isoformat())
    folder = Path(args.output)
    folder.mkdir(parents=True, exist_ok=True)
    from jev_ultrafast import Agent
    agent = Agent(URL, scenario["goal"])
    completion_source = None
    try:
        for state in agent.run():
            last = state["history"][-1] if state["history"] else {}
            print(state["elapsed_ms"], state["status"], last.get("action", ""), flush=True)
            if verify(agent.browser.observe(screenshot=False), scenario["departure"])["passed"]:
                completion_source = "independent_verifier"
                break
    finally:
        state = agent.snapshot()
        state["final_page"] = agent.browser.observe(screenshot=False)
        state["verification"] = verify(state["final_page"], scenario["departure"])
        state["completion_source"] = completion_source
        state["departure"] = scenario["departure"]
        (folder / "state.json").write_text(json.dumps(state, indent=2))
        (folder / "session.json").write_text(
            json.dumps({"target": agent.browser.target, "session": agent.browser.session})
        )
        if not args.keep_open:
            agent.close()
    print(json.dumps(state["verification"], indent=2))
    if not state["verification"]["passed"]:
        raise SystemExit("Final page did not satisfy the route/date checks")


if __name__ == "__main__":
    main()
