"""Semantic progress evidence, separate from the browser's DOM freshness guards."""

import hashlib
import json
from collections import Counter

CONTROL_FIELDS = ("kind", "label", "role", "value", "current_value", "checked", "selected", "expanded")
CYCLE_WINDOW = 32


def _encoded(value):
    return json.dumps(value, sort_keys=True, ensure_ascii=False, separators=(",", ":"))


def semantic_key(page):
    """Ignore node identity and layout churn while retaining visible task state."""
    controls = [{key: action[key] for key in CONTROL_FIELDS if key in action}
                for action in page.get("actions", [])]
    # Snapshot enumeration order may change when an equivalent DOM is rebuilt.
    controls.sort(key=_encoded)
    scroll = page.get("scroll") or {}
    meaningful = {
        "url": page.get("url", ""), "title": page.get("title", ""), "text": page.get("text", ""),
        "controls": controls, "scroll": {key: scroll.get(key, 0) for key in ("x", "y")},
    }
    return hashlib.sha256(_encoded(meaningful).encode()).hexdigest()


def action_signature(action):
    """A requested operation/value remains the same after DOM nodes are replaced."""
    meaningful = {"kind": action.get("kind"), "label": action.get("label"), "value": action.get("value")}
    return hashlib.sha256(_encoded(meaningful).encode()).hexdigest()


def no_progress(item):
    """Read older traces conservatively when semantic evidence is unavailable."""
    return item.get("semantic_changed", item.get("page_changed")) is False


def repeated_noops(page, history):
    """Mask repeated no-ops and recurrent transitions within a bounded recent window.

    WAIT remains available. A state change resets the consecutive no-op evidence.
    Separately, two identical observed transitions in the recent window identify
    a cycle; transitions with a different start state or result are not combined.
    """
    current = semantic_key(page)
    counts = Counter()
    for item in reversed(history):
        if item.get("semantic_before") != current or item.get("semantic_after") != current:
            break
        if item.get("semantic_changed") is not False:
            break
        if item.get("kind") != "wait" and isinstance(item.get("action_signature"), str):
            counts[item["action_signature"]] += 1
    masked = {signature for signature, count in counts.items() if count >= 2}
    # A -> B -> A loops can change visible state on every action, while never
    # advancing the goal. Suppress only an exact repeated A/action/B transition,
    # not a similarly named action in a different state or with a different result.
    transitions = Counter()
    for item in history[-CYCLE_WINDOW:]:
        before, after = item.get("semantic_before"), item.get("semantic_after")
        signature = item.get("action_signature")
        if (item.get("kind") != "wait" and before == current and isinstance(after, str)
                and after != before and isinstance(signature, str)):
            transitions[(signature, after)] += 1
    masked.update(signature for (signature, _after), count in transitions.items() if count >= 2)
    return masked
